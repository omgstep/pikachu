package pbean;

import vbean.VUserInfo;

public class UserInfo {

	private String userid;
	private String password;
	private String name;
	private String eamil;

	public UserInfo() {
	}

	public UserInfo(VUserInfo vuserInfo) {
		this.userid = vuserInfo.getUserid();
		this.password = vuserInfo.getPassword();
		this.name = vuserInfo.getName();
		this.eamil = vuserInfo.getEamil();
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEamil() {
		return eamil;
	}

	public void setEamil(String eamil) {
		this.eamil = eamil;
	}

}
